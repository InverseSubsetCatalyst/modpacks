// priority: 0

// Visit the wiki for more info - https://kubejs.com/

console.info('Hello, World! (Loaded server scripts)')

ServerEvents.recipes(event => {
  event.recipes.create.filling(
    Item.of('vampirism:blood_bottle', '{Damage:9}'), // Full blood bottle
    [
      'minecraft:glass_bottle',
      Fluid.of('vampirism:blood', 25) // 1000 mB for full
    ]
  )
})